/** Automatically generated file. DO NOT MODIFY */
package com.example.encryptions;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}