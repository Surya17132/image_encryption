/** Automatically generated file. DO NOT MODIFY */
package com.example.imageencryption;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}